#part 1
setwd("C:\\Users\\it24101669\\Desktop\\IT24101669\\Lab 04")

data<-read.table("DATA 4.txt",header = TRUE,sep =
                   "")
fix(data)
attach(data)

#part 2
boxplot(X1,main="Box plot for Team Attendence",outline=TRUE,outpch=8,horizontal=TRUE)
boxplot(X2,main="Box plot for Team Sasry",outline=TRUE,outpch=8,horizontal=TRUE)
boxplot(X3,main="Box plot for Years",outlinr=TRUE,outpch=8,horizontal=TRUE)

hist(X1,ylab="Frequency",xlab="Team Attendence",main="Histogram for Team attendence")
hist(X2,ylab="Frequency",xlab="Team Salary",main="Histogram for Team Salary")
hist(X3,ylab="Frequency",xlab="Years",main="Histogram for Years")

stem(X1)
stem(X2)
stem(X3)

mean(X1)
mean(X2)
mean(X3)

sd(X1)
sd(X2)
sd(X3)

summary(X1)
summary(X2)
summary(X3)

quantile(X1)
quantile(X1)[2]
quantile(X1)[4]

IQR(X1)
IQR(X2)
IQR(X3)

#part3
get.mode<-function(y){
  counts<-table(X3)
  name(counts[counts == max(counts)])
}
get.mode(X3)
table(X3)
max(counts)
counts[counts == max(counts)]
name(counts[counts == max(counts)])

#part4
get.outliers <- function(x) {
  q1 <- quantile(x)[2]
  q3 <- quantile(x)[4]
  iqr <- q3 - q1
  lb <- q1 - 1.5 * iqr
  ub <- q3 + 1.5 * iqr
  
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  print(paste("Outliers:", paste(sort(x[x < lb | x > ub]), collapse = ",")))
}
get.outliers(X1)
get.outliers(X2)
get.outliers(X3)

get.outliers <- function(x) {
  q1 <- quantile(x)[2]
  q3 <- quantile(x)[4]
  iqr <- q3 - q1
  lb <- q1 - 1.5 * iqr
  ub <- q3 + 1.5 * iqr
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  print(paste("Outliers:", paste(sort(x[x < lb | x > ub]), collapse = ",")))
}


branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")
head(branch_data)
boxplot(branch_data$Sales,
        main = "Boxplot of Sales",
        ylab = "Sales",
        col = "lightblue")


fivenum(branch_data$Advertising)

summary(branch_data$Advertising)

IQR(branch_data$Advertising)


find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR <- Q3 - Q1
  lower <- Q1 - 1.5 * IQR
  upper <- Q3 + 1.5 * IQR
  outliers <- x[x < lower | x > upper]
  return(outliers)
}
find_outliers(branch_data$Years)
